<template>
  <div class="comment-item" :style="{ marginLeft: depth * 24 + 'px' }">
    <div class="comment-header">
      <div class="comment-user">
        <span class="comment-avatar">{{ (comment.commenter || '?').charAt(0) }}</span>
        <span class="comment-name">{{ comment.commenter || '匿名用户' }}</span>
        <span class="comment-time">{{ formatTime(comment.createTime) }}</span>
      </div>
    </div>

    <div class="comment-body">{{ comment.comment }}</div>

    <div class="comment-actions">
      <span class="comment-action" @click="toggleReply">回复</span>
      <span class="comment-action delete" @click="handleDelete">删除</span>
    </div>

    <div v-if="showReplyForm" class="reply-box">
      <el-input
        v-model="replyContent"
        :rows="2"
        type="textarea"
        placeholder="写下回复..."
        resize="none"
      />
      <div class="reply-actions">
        <el-button size="small" @click="cancelReply">取消</el-button>
        <el-button size="small" type="danger" @click="submitReply">回复</el-button>
      </div>
    </div>

    <div v-if="comment.replies && comment.replies.length" class="sub-comments">
      <comment-item
        v-for="reply in comment.replies"
        :key="reply.id"
        :comment="reply"
        :depth="depth + 1"
        @reply="emitReply"
        @delete="emitDelete"
      />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessageBox } from 'element-plus'

const props = defineProps({
  comment: { type: Object, required: true },
  depth: { type: Number, default: 0 }
})

const emit = defineEmits(['reply', 'delete'])

const showReplyForm = ref(false)
const replyContent = ref('')

const toggleReply = () => { showReplyForm.value = !showReplyForm.value }
const cancelReply = () => { showReplyForm.value = false; replyContent.value = '' }

const submitReply = () => {
  if (!replyContent.value.trim()) return
  emit('reply', { ...props.comment, replyContent: replyContent.value })
  showReplyForm.value = false
  replyContent.value = ''
}

const handleDelete = () => {
  ElMessageBox.confirm('确定删除？', '提示', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    .then(() => emit('delete', props.comment.id))
    .catch(() => {})
}

const emitReply = (c) => emit('reply', c)
const emitDelete = (id) => emit('delete', id)

const formatTime = (t) => {
  if (!t) return ''
  return new Date(t).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })
}
</script>

<style scoped>
.comment-item {
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
}

.comment-item:last-child {
  border-bottom: none;
}

.comment-header {
  margin-bottom: 6px;
}

.comment-user {
  display: flex;
  align-items: center;
  gap: 8px;
}

.comment-avatar {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: #f0f0f0;
  color: #666;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  flex-shrink: 0;
}

.comment-name {
  font-size: 13px;
  font-weight: 500;
  color: #1a1a1a;
}

.comment-time {
  font-size: 11px;
  color: #c0c4cc;
}

.comment-body {
  font-size: 14px;
  color: #303133;
  line-height: 1.6;
  margin-left: 36px;
  margin-bottom: 6px;
  word-break: break-word;
  white-space: pre-wrap;
}

.comment-actions {
  display: flex;
  gap: 16px;
  margin-left: 36px;
}

.comment-action {
  font-size: 12px;
  color: #909399;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}

.comment-action.delete {
  color: #ccc;
}

.comment-action.delete:active {
  color: #E01E26;
}

.reply-box {
  margin: 10px 0 6px 36px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.reply-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.sub-comments {
  margin-top: 4px;
}
</style>
