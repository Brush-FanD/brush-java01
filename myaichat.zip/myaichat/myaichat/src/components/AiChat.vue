<template>
  <div class="chat-container">
    <!-- ========== 顶部标题栏 ========== -->
    <div class="chat-header">
      <div class="header-left">
        <div class="header-avatar">
          <el-icon :size="18"><ChatDotRound /></el-icon>
        </div>
        <div>
          <span class="header-title">懂车AI</span>
          <span class="header-subtitle">汽车智能助手</span>
        </div>
      </div>
      <div class="header-right">
        <el-radio-group v-model="chatMode" size="small">
          <el-radio-button value="sync">同步</el-radio-button>
          <el-radio-button value="stream">流式</el-radio-button>
        </el-radio-group>
      </div>
    </div>

    <!-- ========== 消息列表 ========== -->
    <div class="chat-body" ref="messageContainer">
      <!-- 空状态 -->
      <div v-if="messages.length === 0" class="empty-state">
        <div class="empty-icon">
          <span style="font-size:56px">🤖</span>
        </div>
        <p class="empty-title">你好！我是懂车AI</p>
        <p class="empty-desc">买车、看车、用车，任何汽车问题都可以问我~</p>
      </div>

      <!-- 消息气泡 -->
      <div
        v-for="(msg, index) in messages"
        :key="index"
        :class="['message-row', msg.role === 'user' ? 'row-right' : 'row-left']"
      >
        <!-- AI 头像 -->
        <div v-if="msg.role === 'assistant'" class="avatar avatar-ai">
          <el-icon :size="18"><Service /></el-icon>
        </div>

        <div class="bubble-wrapper">
          <!-- 角色名 -->
          <div class="bubble-name">
            {{ msg.role === 'user' ? '我' : '懂车AI' }}
            <!-- 打字中状态 -->
            <span v-if="msg.isStreaming" class="typing-dot">●</span>
          </div>
          <!-- 气泡 -->
          <div :class="['bubble', msg.role === 'user' ? 'bubble-user' : 'bubble-ai']">
            <div class="bubble-text">{{ msg.content }}</div>
            <span v-if="msg.isStreaming" class="cursor">|</span>
          </div>
        </div>

        <!-- 用户头像 -->
        <div v-if="msg.role === 'user'" class="avatar avatar-user">
          <el-icon :size="18"><UserFilled /></el-icon>
        </div>
      </div>

      <!-- 加载骨架 -->
      <div v-if="isLoading && messages.length > 0 && messages[messages.length-1].role==='user'" class="message-row row-left">
        <div class="avatar avatar-ai">
          <el-icon :size="18"><Service /></el-icon>
        </div>
        <div class="bubble-wrapper">
          <div class="bubble-name">懂车AI</div>
          <div class="bubble bubble-ai thinking">
            <span class="dot-pulse"></span>
          </div>
        </div>
      </div>
    </div>

    <!-- ========== 底部输入区 ========== -->
    <div class="chat-footer">
      <div class="footer-inner">
        <el-input
          v-model="inputMessage"
          placeholder="输入汽车相关问题，按 Enter 发送…"
          :disabled="isLoading"
          :autosize="{ minRows: 1, maxRows: 4 }"
          type="textarea"
          resize="none"
          @keyup.enter.exact="sendMessage"
          class="msg-input"
        />
        <el-button
          type="danger"
          :disabled="!inputMessage.trim() || isLoading"
          :loading="isLoading"
          @click="sendMessage"
          class="send-btn"
        >
          <span v-if="!isLoading">发送</span>
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { nextTick, ref } from 'vue'
import { ChatDotRound, Service, UserFilled } from '@element-plus/icons-vue'

const chatMode = ref('sync')
const inputMessage = ref('')
const messages = ref([])
const messageContainer = ref(null)
const isLoading = ref(false)

let eventSource = null
const conversationId = ref('user-' + Date.now())

const scrollToBottom = () => {
  nextTick(() => {
    if (messageContainer.value) {
      messageContainer.value.scrollTop = messageContainer.value.scrollHeight
    }
  })
}

const sendMessage = () => {
  const message = inputMessage.value.trim()
  if (!message || isLoading.value) return

  messages.value.push({ role: 'user', content: message, isStreaming: false })
  inputMessage.value = ''
  isLoading.value = true

  if (chatMode.value === 'sync') {
    sendSyncMessage(message)
  } else {
    sendStreamMessage(message)
  }
  scrollToBottom()
}

const sendSyncMessage = async (message) => {
  try {
    const response = await fetch('/api/web/aichat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, conversationId: conversationId.value })
    })
    const result = await response.json()
    if (result.code === 200) {
      messages.value.push({ role: 'assistant', content: result.data, isStreaming: false })
    } else {
      messages.value.push({ role: 'assistant', content: '抱歉，出现问题了，请稍后再试！', isStreaming: false })
    }
  } catch {
    messages.value.push({ role: 'assistant', content: '抱歉，网络连接失败，请检查网络！', isStreaming: false })
  } finally {
    isLoading.value = false
    scrollToBottom()
  }
}

const sendStreamMessage = (message) => {
  const aiMessage = { role: 'assistant', content: '', isStreaming: true }
  messages.value.push(aiMessage)

  const url = `/api/web/chatstream?conversationId=${encodeURIComponent(conversationId.value)}&message=${encodeURIComponent(message)}`
  eventSource = new EventSource(url)

  eventSource.onmessage = (event) => {
    aiMessage.content += event.data
    scrollToBottom()
  }

  eventSource.onerror = () => {
    if (eventSource) { eventSource.close(); eventSource = null }
    aiMessage.isStreaming = false
    isLoading.value = false
  }
}
</script>

<style scoped>
/* ========== 整体容器 ========== */
.chat-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: #f4f5f7;
  border-radius: 0;
}

/* ========== 顶部 ========== */
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 20px;
  background: linear-gradient(135deg, #E01E26, #B0151B);
  color: #fff;
  flex-shrink: 0;
}
.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}
.header-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: rgba(255,255,255,0.2);
  display: flex;
  align-items: center;
  justify-content: center;
}
.header-title {
  font-size: 17px;
  font-weight: 600;
  letter-spacing: 0.5px;
  display: block;
}
.header-subtitle {
  font-size: 11px;
  opacity: 0.8;
  display: block;
  margin-top: 1px;
}

/* ========== 消息区域 ========== */
.chat-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px 16px;
  background: #f0f2f5;
  scroll-behavior: smooth;
}
/* 滚动条美化 */
.chat-body::-webkit-scrollbar { width: 5px; }
.chat-body::-webkit-scrollbar-thumb { background: #c0c4cc; border-radius: 3px; }

/* 空状态 */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding-top: 20%;
}
.empty-icon { margin-bottom: 12px; }
.empty-title { font-size: 17px; color: #303133; font-weight: 500; margin: 0 0 6px; }
.empty-desc { font-size: 13px; color: #999; margin: 0; }

/* ========== 消息行 ========== */
.message-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 18px;
  animation: fadeUp 0.25s ease;
}
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
.row-right { flex-direction: row-reverse; }

/* 头像 */
.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.avatar-ai {
  background: #fff2f0;
  color: #E01E26;
}
.avatar-user {
  background: #E01E26;
  color: #fff;
}

/* 气泡包裹 */
.bubble-wrapper {
  max-width: 70%;
  display: flex;
  flex-direction: column;
}
.row-right .bubble-wrapper { align-items: flex-end; }

/* 角色名 */
.bubble-name {
  font-size: 12px;
  color: #909399;
  margin-bottom: 4px;
  padding: 0 4px;
}
.typing-dot {
  color: #E01E26;
  font-size: 10px;
  animation: blink 0.8s infinite;
  margin-left: 2px;
  vertical-align: middle;
}

/* ========== 气泡 ========== */
.bubble {
  padding: 10px 14px;
  border-radius: 16px;
  font-size: 14px;
  line-height: 1.7;
  word-break: break-word;
  white-space: pre-wrap;
  position: relative;
}
.bubble-user {
  background: linear-gradient(135deg, #E01E26, #FF4D4F);
  color: #fff;
  border-top-right-radius: 4px;
}
.bubble-ai {
  background: #fff;
  color: #303133;
  border: 1px solid #e8e8e8;
  border-top-left-radius: 4px;
}
.bubble-text {
  white-space: pre-wrap;
}

/* 光标 */
.cursor {
  animation: blink 0.8s infinite;
  font-weight: 300;
  color: #E01E26;
}
@keyframes blink {
  0%, 100% { opacity: 1; }
  50%      { opacity: 0; }
}

/* 加载动画 */
.thinking { padding: 14px 18px; }
.dot-pulse::after {
  content: '...';
  animation: dotAnim 1.4s infinite;
  font-size: 18px;
  letter-spacing: 2px;
  color: #999;
}
@keyframes dotAnim {
  0%   { content: '.'; }
  33%  { content: '..'; }
  66%  { content: '...'; }
}

/* ========== 底部输入区 ========== */
.chat-footer {
  flex-shrink: 0;
  padding: 12px 16px 16px;
  background: #fff;
  border-top: 1px solid #ebeef5;
}
.footer-inner {
  display: flex;
  gap: 10px;
  align-items: flex-end;
}
.msg-input :deep(.el-textarea__inner) {
  border-radius: 10px;
  background: #f5f7fa;
  border: 1px solid #e4e7ed;
  font-size: 14px;
  line-height: 1.6;
  padding: 8px 12px;
  transition: border-color 0.2s;
}
.msg-input :deep(.el-textarea__inner:focus) {
  border-color: #E01E26;
  background: #fff;
}
.send-btn {
  height: 38px;
  border-radius: 10px;
  padding: 0 22px;
  flex-shrink: 0;
}
</style>
