import { createRouter, createWebHistory } from 'vue-router'
import HomeFeed from './views/HomeFeed.vue'
import CarSelect from './views/CarSelect.vue'
import VideoManagement from './views/VideoManagement.vue'
import VideoView from './views/VideoView.vue'

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'HomeFeed',
    component: HomeFeed,
    meta: { title: '首页' }
  },
  {
    path: '/cars',
    name: 'CarSelect',
    component: CarSelect,
    meta: { title: '选车' }
  },
  {
    path: '/videos',
    name: 'VideoManagement',
    component: VideoManagement,
    meta: { title: '视频库' }
  },
  {
    path: '/video/:videoId',
    name: 'VideoView',
    component: VideoView,
    meta: { title: '视频详情' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
