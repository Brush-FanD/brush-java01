<template>
  <div class="car-page">
    <div class="car-search">
      <div class="car-search-bar">
        <span>🔍</span>
        <span class="car-search-text">搜索品牌或车型...</span>
      </div>
    </div>

    <div class="section">
      <div class="section-header">
        <span>热门品牌</span>
        <span class="section-link">全部 ▸</span>
      </div>
      <div class="brand-scroll">
        <div v-for="brand in brandList" :key="brand.name" class="brand-item" :class="{ active: selectedBrand === brand.name }" @click="selectBrand(brand.name)">
          <div class="brand-avatar">{{ brand.icon }}</div>
          <span class="brand-name">{{ brand.name }}</span>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="filter-row"><span class="filter-label">价格</span>
        <div class="filter-scroll">
          <span v-for="p in priceFilters" :key="p" class="filter-chip" :class="{ active: selectedPrice === p }" @click="selectedPrice = p">{{ p }}</span>
        </div>
      </div>
      <div class="filter-row"><span class="filter-label">类型</span>
        <div class="filter-scroll">
          <span v-for="t in typeFilters" :key="t" class="filter-chip" :class="{ active: selectedType === t }" @click="selectedType = t">{{ t }}</span>
        </div>
      </div>
      <div class="filter-row"><span class="filter-label">能源</span>
        <div class="filter-scroll">
          <span v-for="e in energyFilters" :key="e" class="filter-chip" :class="{ active: selectedEnergy === e }" @click="selectedEnergy = e">{{ e }}</span>
        </div>
      </div>
    </div>

    <div class="section result-section">
      <div class="section-header">
        <span>共 {{ filteredCars.length }} 款车型</span>
      </div>
      <div v-if="filteredCars.length" class="car-grid">
        <div v-for="car in filteredCars" :key="car.id" class="car-card" @click="goDetail(car)">
          <div class="car-img-box">
            <img :src="car.img" :alt="car.name" loading="lazy" @error="onImgError($event)" />
            <span class="car-emoji-bg">🚗</span>
            <span class="car-badge">{{ car.price }}</span>
          </div>
          <div class="car-info">
            <div class="car-name">{{ car.name }}</div>
            <div class="car-sub">{{ car.desc }}</div>
            <div class="car-tags">
              <span v-for="t in car.tags" :key="t" class="car-tag">{{ t }}</span>
            </div>
          </div>
        </div>
      </div>
      <div v-else class="empty-state">
        <span style="font-size:40px">🚗</span>
        <p>没有找到匹配的车型</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// 图片加载失败时显示备用
const onImgError = (e) => {
  e.target.style.display = 'none'
  const parent = e.target.parentNode
  if (!parent.querySelector('.img-fallback')) {
    const fb = document.createElement('span')
    fb.className = 'img-fallback'
    fb.textContent = '🚗'
    fb.style.cssText = 'font-size:48px;position:absolute;inset:0;display:flex;align-items:center;justify-content:center;'
    parent.appendChild(fb)
  }
}

const brandList = [
  { name: '比亚迪', icon: '🚗' }, { name: '特斯拉', icon: '⚡' }, { name: '理想', icon: '🚀' },
  { name: '问界', icon: '🏔️' }, { name: '小鹏', icon: '🪽' }, { name: '蔚来', icon: '💙' },
  { name: '小米', icon: '📱' }, { name: '大众', icon: '🏎️' }, { name: '宝马', icon: '🔵' },
  { name: '奔驰', icon: '⭐' }, { name: '奥迪', icon: '🔴' }, { name: '丰田', icon: '🌐' },
]
const selectedBrand = ref('')
const priceFilters = ['全部', '10万以下', '10-20万', '20-30万', '30-50万', '50万以上']
const typeFilters = ['全部', '轿车', 'SUV', 'MPV', '跑车', '皮卡']
const energyFilters = ['全部', '燃油', '纯电', '混动', '增程']
const selectedPrice = ref('全部')
const selectedType = ref('全部')
const selectedEnergy = ref('全部')

const carList = ref([
  { id: 1, name: '秦L DM-i', desc: '插电混动·中型轿车', price: '9.98-13.98万', img: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400&h=300&fit=crop', tags: ['混动','家用'], brand: '比亚迪', priceRange: '10万以下', type: '轿车', energy: '混动' },
  { id: 2, name: 'Model Y', desc: '纯电·中型SUV', price: '24.99-35.49万', img: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58d1?w=400&h=300&fit=crop', tags: ['纯电','智能'], brand: '特斯拉', priceRange: '20-30万', type: 'SUV', energy: '纯电' },
  { id: 3, name: '理想 L9', desc: '增程·大型SUV', price: '42.98-45.98万', img: 'https://images.unsplash.com/photo-1554744511-d6c603f27c54?w=400&h=300&fit=crop', tags: ['增程','家庭'], brand: '理想', priceRange: '30-50万', type: 'SUV', energy: '增程' },
  { id: 4, name: '问界 M9', desc: '增程/纯电·大型SUV', price: '46.98-56.98万', img: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400&h=300&fit=crop', tags: ['智驾','豪华'], brand: '问界', priceRange: '30-50万', type: 'SUV', energy: '增程' },
  { id: 5, name: '小米 SU7', desc: '纯电·中大型轿车', price: '21.59-29.99万', img: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?w=400&h=300&fit=crop', tags: ['性能','轿跑'], brand: '小米', priceRange: '20-30万', type: '轿车', energy: '纯电' },
  { id: 6, name: '小鹏 G6', desc: '纯电·中型SUV', price: '20.99-27.69万', img: 'https://images.unsplash.com/photo-1550355291-bbee04a92027?w=400&h=300&fit=crop', tags: ['智驾','SUV'], brand: '小鹏', priceRange: '20-30万', type: 'SUV', energy: '纯电' },
  { id: 7, name: '蔚来 ES6', desc: '纯电·中型SUV', price: '33.80-39.60万', img: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=400&h=300&fit=crop', tags: ['换电','豪华'], brand: '蔚来', priceRange: '30-50万', type: 'SUV', energy: '纯电' },
  { id: 8, name: '帕萨特', desc: '燃油·中型轿车', price: '18.19-25.29万', img: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400&h=300&fit=crop', tags: ['经典','商务'], brand: '大众', priceRange: '10-20万', type: '轿车', energy: '燃油' },
  { id: 9, name: '宝马 3系', desc: '燃油·中型轿车', price: '29.99-39.99万', img: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400&h=300&fit=crop', tags: ['豪华','操控'], brand: '宝马', priceRange: '20-30万', type: '轿车', energy: '燃油' },
  { id: 10, name: '奔驰 GLC', desc: '燃油·中型SUV', price: '42.78-53.13万', img: 'https://images.unsplash.com/photo-1554744511-d6c603f27c54?w=400&h=300&fit=crop', tags: ['豪华','舒适'], brand: '奔驰', priceRange: '30-50万', type: 'SUV', energy: '燃油' },
  { id: 11, name: '奥迪 A6L', desc: '燃油·中大型轿车', price: '42.79-65.68万', img: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?w=400&h=300&fit=crop', tags: ['商务','科技'], brand: '奥迪', priceRange: '30-50万', type: '轿车', energy: '燃油' },
  { id: 12, name: '凯美瑞', desc: '燃油/混动·中型轿车', price: '17.18-25.98万', img: 'https://images.unsplash.com/photo-1550355291-bbee04a92027?w=400&h=300&fit=crop', tags: ['可靠','省心'], brand: '丰田', priceRange: '10-20万', type: '轿车', energy: '混动' },
])

const filteredCars = computed(() => carList.value.filter(car => {
  if (selectedBrand.value && car.brand !== selectedBrand.value) return false
  if (selectedPrice.value !== '全部' && car.priceRange !== selectedPrice.value) return false
  if (selectedType.value !== '全部' && car.type !== selectedType.value) return false
  if (selectedEnergy.value !== '全部' && car.energy !== selectedEnergy.value) return false
  return true
}))

const selectBrand = (name) => { selectedBrand.value = selectedBrand.value === name ? '' : name }
const goDetail = (car) => { router.push({ name: 'VideoView', params: { videoId: car.id } }) }
</script>

<style scoped>
.car-page { background: #f4f5f7; min-height: 100%; padding-bottom: 8px; }
.car-search { padding: 10px 16px; background: #fff; }
.car-search-bar { display: flex; align-items: center; gap: 8px; background: #f5f6f8; border-radius: 20px; padding: 10px 16px; }
.car-search-text { font-size: 14px; color: #909399; }
.section { background: #fff; margin: 10px 12px; border-radius: 10px; padding: 16px; }
.section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; font-size: 15px; font-weight: 600; color: #1a1a1a; }
.section-link { font-size: 12px; font-weight: 400; color: #909399; }
.brand-scroll { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 4px; }
.brand-item { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 10px 6px; min-width: 60px; border-radius: 8px; cursor: pointer; border: 1.5px solid transparent; }
.brand-item.active { background: #fff2f0; border-color: #E01E26; }
.brand-avatar { font-size: 26px; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; background: #f5f6f8; border-radius: 50%; }
.brand-item.active .brand-avatar { background: #fff; }
.brand-name { font-size: 11px; color: #606266; white-space: nowrap; }
.brand-item.active .brand-name { color: #E01E26; font-weight: 600; }
.filter-row { display: flex; gap: 10px; margin-bottom: 12px; align-items: flex-start; }
.filter-row:last-child { margin-bottom: 0; }
.filter-label { font-size: 13px; color: #909399; width: 36px; flex-shrink: 0; line-height: 30px; }
.filter-scroll { display: flex; gap: 8px; flex-wrap: wrap; }
.filter-chip { padding: 5px 14px; font-size: 12px; color: #606266; background: #f5f6f8; border-radius: 14px; cursor: pointer; }
.filter-chip.active { color: #E01E26; background: #fff2f0; font-weight: 500; }
.result-section { padding-bottom: 20px; }
.car-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.car-card { background: #f8f9fa; border-radius: 10px; overflow: hidden; cursor: pointer; }
.car-card:active { transform: scale(0.97); }
.car-img-box { position: relative; aspect-ratio: 4/3; background: #1a1a2e; overflow: hidden; display: flex; align-items: center; justify-content: center; }
.car-img-box img { width: 100%; height: 100%; object-fit: cover; position: relative; z-index: 1; }
.car-emoji-bg { position: absolute; font-size: 54px; color: rgba(255,255,255,0.12); z-index: 0; pointer-events: none; }
.car-badge { position: absolute; right: 6px; bottom: 6px; background: rgba(224,30,38,0.9); color: #fff; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 4px; }
.car-info { padding: 10px 10px 12px; }
.car-name { font-size: 13px; font-weight: 600; color: #1a1a1a; margin-bottom: 2px; }
.car-sub { font-size: 11px; color: #909399; margin-bottom: 6px; }
.car-tags { display: flex; gap: 4px; }
.car-tag { font-size: 10px; color: #E01E26; background: #fff2f0; padding: 1px 6px; border-radius: 3px; }
.empty-state { text-align: center; padding: 40px 0; color: #c0c4cc; display: flex; flex-direction: column; align-items: center; gap: 10px; }
.empty-state p { font-size: 13px; }
</style>
