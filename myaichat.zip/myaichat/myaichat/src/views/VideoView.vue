<template>
  <div class="video-detail">
    <div v-if="videoUrl" class="player-wrap">
      <video :src="videoUrl" controls class="player"></video>
    </div>
    <div v-else class="player-placeholder">
      <span style="font-size:40px">🎬</span>
      <p>加载中...</p>
    </div>

    <div class="detail-info" v-if="videoTitle">
      <h1 class="detail-title">{{ videoTitle }}</h1>
      <div class="detail-meta">
        <span>懂车帝</span>
        <span>0次播放</span>
        <span>刚刚</span>
      </div>
    </div>

    <div class="action-bar">
      <div class="action-item"><span style="font-size:20px">⭐</span><span>收藏</span></div>
      <div class="action-item"><span style="font-size:20px">🔗</span><span>分享</span></div>
      <div class="action-item"><span style="font-size:20px">💬</span><span>{{ comments.length }}</span></div>
      <div class="action-item"><span style="font-size:20px">👍</span><span>点赞</span></div>
    </div>

    <div class="comments-area">
      <div class="comments-header"><span>评论（{{ comments.length }}）</span></div>
      <div class="comment-input-wrap">
        <input v-model="newComment.content" placeholder="发表你的看法..." class="comment-input" />
        <button class="comment-btn" @click="addComment">发表</button>
      </div>
      <div class="comments-list">
        <comment-item
          v-for="comment in comments"
          :key="comment.id"
          :comment="comment"
          @reply="handleReply"
          @delete="deleteComment"
        />
        <div v-if="!comments.length" class="no-comments">
          <span style="font-size:32px">💬</span>
          <p>暂无评论</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'
import CommentItem from '../components/CommentItem.vue'

const route = useRoute()
const videoTitle = ref('')
const videoUrl = ref('')
const comments = ref([])
const newComment = reactive({ content: '' })

onMounted(() => {
  fetchVideoDetails()
  fetchComments()
})

const fetchVideoDetails = async () => {
  try {
    const id = route.params.videoId
    const res = await axios.get(`/videos/${id}`)
    videoTitle.value = res.data.videoName || '视频详情'
    videoUrl.value = `http://www.hphs.com${res.data.videoPath}`
  } catch {
    videoTitle.value = '汽车评测视频'
  }
}

const initComments = (list) => {
  return (list || []).map(c => ({
    ...c, showReply: false, replyContent: '',
    replies: c.childComments ? initComments(c.childComments) : []
  }))
}

const fetchComments = async () => {
  try {
    const res = await axios.get(`/video-comments/${route.params.videoId}`)
    comments.value = initComments(res.data)
  } catch {}
}

const addComment = async () => {
  if (!newComment.content.trim()) return
  try {
    const res = await axios.post('/video-comments', {
      videoId: Number(route.params.videoId), comment: newComment.content
    })
    if (res.data) {
      comments.value.unshift(initComments([res.data])[0])
      newComment.content = ''
    }
  } catch {}
}

const handleReply = async (comment) => {
  if (!comment.replyContent.trim()) return
  try {
    const res = await axios.post('/video-comments', {
      videoId: Number(route.params.videoId),
      parentCommentId: comment.id, comment: comment.replyContent
    })
    if (res.data) {
      comment.replies.unshift(initComments([res.data])[0])
      comment.showReply = false; comment.replyContent = ''
    }
  } catch {}
}

const deleteComment = async (commentId) => {
  try {
    await axios.delete(`/video-comments/${commentId}`)
    comments.value = comments.value.filter(c => c.id !== commentId)
  } catch {}
}
</script>

<style scoped>
.video-detail { background: #fff; min-height: 100%; }
.player-wrap { width: 100%; background: #000; }
.player { width: 100%; aspect-ratio: 16/9; display: block; outline: none; }
.player-placeholder { width: 100%; aspect-ratio: 16/9; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #1a1a1a; color: #c0c4cc; gap: 8px; }
.player-placeholder p { font-size: 13px; margin: 0; }
.detail-info { padding: 14px 16px 0; }
.detail-title { font-size: 17px; font-weight: 600; color: #1a1a1a; margin: 0 0 8px; line-height: 1.5; }
.detail-meta { display: flex; gap: 12px; font-size: 12px; color: #909399; }
.action-bar { display: flex; padding: 14px 16px; border-bottom: 6px solid #f4f5f7; }
.action-item { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; color: #606266; font-size: 11px; cursor: pointer; }
.comments-area { padding: 14px 16px 20px; }
.comments-header { font-size: 15px; font-weight: 600; color: #1a1a1a; margin-bottom: 12px; }
.comment-input-wrap { display: flex; gap: 8px; margin-bottom: 16px; }
.comment-input { flex: 1; border: 1px solid #e4e7ed; border-radius: 8px; padding: 8px 12px; font-size: 14px; outline: none; font-family: inherit; }
.comment-input:focus { border-color: #E01E26; }
.comment-btn { background: #E01E26; color: #fff; border: none; border-radius: 16px; padding: 8px 18px; font-size: 13px; cursor: pointer; flex-shrink: 0; }
.comments-list { min-height: 60px; }
.no-comments { display: flex; flex-direction: column; align-items: center; padding: 30px 0; color: #c0c4cc; gap: 8px; }
.no-comments p { font-size: 13px; margin: 0; }
</style>
