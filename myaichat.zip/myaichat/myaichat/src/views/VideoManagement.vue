<template>
  <div class="video-mgr">
    <div class="mgr-header">
      <span class="mgr-title">视频库</span>
      <button class="mgr-upload-btn" @click="showAddDialog = true">＋ 上传</button>
    </div>
    <div class="mgr-search">
      <input v-model="searchQuery" placeholder="搜索视频名称..." class="mgr-search-input" @keyup.enter="handleSearch" />
    </div>
    <div v-if="filteredVideos.length" class="mgr-list">
      <div v-for="item in filteredVideos" :key="item.id" class="mgr-item" @click="handleEdit(item)">
        <div class="mgr-item-img">
          <img :src="formatImagePath(item.image)" alt="" />
          <span class="mgr-play-icon">▶</span>
        </div>
        <div class="mgr-item-info">
          <div class="mgr-item-title">{{ item.videoName }}</div>
          <div class="mgr-item-meta">ID: {{ item.id }}</div>
        </div>
        <button class="mgr-del-btn" @click.stop="handleDelete(item.id)">✕</button>
      </div>
    </div>
    <div v-else class="mgr-empty">
      <span style="font-size:48px">🎬</span>
      <p>暂无视频</p>
    </div>

    <el-dialog v-model="showAddDialog" title="上传视频" width="92%" top="5vh">
      <el-form :model="newVideo" label-width="80px" ref="addFormRef">
        <el-form-item label="名称" prop="videoName" :rules="[{ required: true, message: '请输入视频名称' }]">
          <el-input v-model="newVideo.videoName" />
        </el-form-item>
        <el-form-item label="视频">
          <el-upload action="#" :on-change="handleVideoChange" :show-file-list="false" accept="video/*">
            <el-button size="small" type="danger">选择视频</el-button>
          </el-upload>
          <span v-if="newVideo.videoFile" class="file-tip">已选: {{ newVideo.videoFile.name }}</span>
        </el-form-item>
        <el-form-item label="封面">
          <el-upload action="#" :on-change="handleImageChange" :show-file-list="false" accept="image/*">
            <el-button size="small" type="danger">选择图片</el-button>
          </el-upload>
          <span v-if="newVideo.imageFile" class="file-tip">已选: {{ newVideo.imageFile.name }}</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="danger" @click="submitAddForm" :loading="submitLoading">保存</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="showEditDialog" title="编辑视频" width="92%" top="5vh">
      <el-form :model="editedVideo" label-width="80px" ref="editFormRef">
        <el-form-item label="名称" prop="videoName" :rules="[{ required: true, message: '请输入视频名称' }]">
          <el-input v-model="editedVideo.videoName" />
        </el-form-item>
        <el-form-item label="视频">
          <el-upload action="#" :on-change="handleEditVideoChange" :show-file-list="false" accept="video/*">
            <el-button size="small" type="danger">选择视频</el-button>
          </el-upload>
          <span v-if="editedVideo.videoFile" class="file-tip">已选: {{ editedVideo.videoFile.name }}</span>
        </el-form-item>
        <el-form-item label="封面">
          <el-upload action="#" :on-change="handleEditImageChange" :show-file-list="false" accept="image/*">
            <el-button size="small" type="danger">选择图片</el-button>
          </el-upload>
          <span v-if="editedVideo.imageFile" class="file-tip">已选: {{ editedVideo.imageFile.name }}</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showEditDialog = false">取消</el-button>
        <el-button type="danger" @click="submitEditForm" :loading="submitLoading">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import axios from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'

const searchQuery = ref('')
const showAddDialog = ref(false)
const showEditDialog = ref(false)
const submitLoading = ref(false)
const videos = ref([])
const addFormRef = ref(null)
const editFormRef = ref(null)
const newVideo = reactive({ videoName: '', videoFile: null, imageFile: null })
const editedVideo = reactive({ id: '', videoName: '', videoFile: null, imageFile: null })

const filteredVideos = computed(() => {
  const q = searchQuery.value.toLowerCase().trim()
  if (!q) return videos.value
  return videos.value.filter(v => v.videoName.toLowerCase().includes(q))
})

onMounted(fetchVideos)

function fetchVideos() {
  axios.get('/videos').then(res => { videos.value = Array.isArray(res.data) ? res.data : (res.data.list || []) }).catch(() => ElMessage.error('获取失败'))
}

function handleSearch() {}

async function submitAddForm() {
  try {
    await addFormRef.value.validate()
    submitLoading.value = true
    const fd = new FormData()
    fd.append('videoName', newVideo.videoName)
    if (newVideo.videoFile) fd.append('file', newVideo.videoFile)
    if (newVideo.imageFile) fd.append('image', newVideo.imageFile)
    await axios.post('/videos/upload', fd)
    ElMessage.success('上传成功')
    showAddDialog.value = false
    newVideo.videoName = ''; newVideo.videoFile = null; newVideo.imageFile = null
    addFormRef.value?.resetFields()
    fetchVideos()
  } catch (e) { if (e.name !== 'Error') ElMessage.error(`上传失败`) }
  finally { submitLoading.value = false }
}

function handleEdit(row) { Object.assign(editedVideo, { id: row.id, videoName: row.videoName, videoFile: null, imageFile: null }); showEditDialog.value = true }

async function submitEditForm() {
  try {
    await editFormRef.value.validate()
    submitLoading.value = true
    const fd = new FormData()
    fd.append('videoName', editedVideo.videoName)
    if (editedVideo.videoFile) fd.append('file', editedVideo.videoFile)
    if (editedVideo.imageFile) fd.append('image', editedVideo.imageFile)
    await axios.put(`/videos/${editedVideo.id}`, fd)
    ElMessage.success('修改成功')
    showEditDialog.value = false
    fetchVideos()
  } catch (e) { if (e.name !== 'Error') ElMessage.error(`修改失败`) }
  finally { submitLoading.value = false }
}

function handleDelete(id) {
  ElMessageBox.confirm('确定删除该视频？', '提示', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
    .then(() => { axios.delete(`/videos/${id}`).then(() => { ElMessage.success('删除成功'); fetchVideos() }).catch(() => ElMessage.error('删除失败')) })
    .catch(() => {})
}

function handleVideoChange(f) { newVideo.videoFile = f.raw }
function handleImageChange(f) { newVideo.imageFile = f.raw }
function handleEditVideoChange(f) { editedVideo.videoFile = f.raw }
function handleEditImageChange(f) { editedVideo.imageFile = f.raw }

const baseUrl = 'http://www.hphs.com'
const formatImagePath = (path) => `${baseUrl}/${path}`
</script>

<style scoped>
.video-mgr { padding: 12px; background: #f4f5f7; min-height: 100%; }
.mgr-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.mgr-title { font-size: 18px; font-weight: 700; color: #1a1a1a; }
.mgr-upload-btn { background: #E01E26; color: #fff; border: none; border-radius: 16px; padding: 6px 16px; font-size: 13px; cursor: pointer; }
.mgr-search { margin-bottom: 12px; }
.mgr-search-input { width: 100%; border: none; border-radius: 20px; padding: 10px 16px; font-size: 14px; background: #fff; outline: none; font-family: inherit; }
.mgr-list { display: flex; flex-direction: column; gap: 10px; }
.mgr-item { display: flex; align-items: center; gap: 12px; background: #fff; border-radius: 10px; padding: 10px; cursor: pointer; }
.mgr-item-img { width: 90px; height: 60px; border-radius: 6px; overflow: hidden; background: #e8e8e8; flex-shrink: 0; position: relative; }
.mgr-item-img img { width: 100%; height: 100%; object-fit: cover; }
.mgr-play-icon { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 24px; background: rgba(0,0,0,0.1); }
.mgr-item-info { flex: 1; min-width: 0; }
.mgr-item-title { font-size: 14px; font-weight: 500; color: #1a1a1a; margin-bottom: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mgr-item-meta { font-size: 12px; color: #909399; }
.mgr-del-btn { border: none; background: none; color: #999; font-size: 16px; cursor: pointer; padding: 4px; }
.mgr-empty { text-align: center; padding: 80px 0; color: #c0c4cc; display: flex; flex-direction: column; align-items: center; gap: 12px; }
.mgr-empty p { font-size: 14px; margin: 0; }
.file-tip { margin-left: 10px; font-size: 12px; color: #67c23a; }
</style>
