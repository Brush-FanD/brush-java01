<template>
  <div class="home-page">
    <!-- 顶部搜索栏（现在是真的输入框，按回车发AI请求） -->
    <div class="top-search">
      <div class="search-input-wrap">
        <span style="color:#999;flex-shrink:0">🔍</span>
        <input
          v-model="searchText"
          class="search-input"
          placeholder="搜车型或问任何汽车问题..."
          @keyup.enter="submitSearch"
        />
      </div>
      <div class="top-actions">💬</div>
    </div>

    <div class="category-scroll">
      <div class="category-inner">
        <span v-for="cat in categories" :key="cat" class="cat-pill" :class="{ active: activeCat === cat }" @click="switchCategory(cat)">{{ cat }}</span>
      </div>
    </div>

    <div class="feed-header">
      <span class="feed-header-title"><span class="red-dot"></span>{{ activeCat }}</span>
      <span class="feed-header-more">共 {{ filteredList.length }} 条</span>
    </div>

    <div v-if="filteredList.length" class="feed-grid">
      <div v-for="item in filteredList" :key="item.id" class="grid-card" @click="goDetail(item)">
        <div class="grid-img" :style="{ background: item.bg }">
          <img :src="item.img" :alt="item.title" loading="lazy" @error="onImgError($event)" />
          <span class="car-emoji-bg">🚗</span>
          <span class="grid-badge" :style="{ background: item.badgeColor }">{{ item.badge }}</span>
          <span class="grid-duration" v-if="item.duration">{{ item.duration }}</span>
        </div>
        <div class="grid-body">
          <h3 class="grid-title">{{ item.title }}</h3>
          <div class="grid-meta">
            <span class="grid-source">{{ item.source }}</span>
            <span class="grid-views">{{ item.views }}</span>
          </div>
        </div>
      </div>
      <div class="list-end">没有更多了</div>
    </div>

    <div v-else class="empty-cat">
      <span style="font-size:48px">📭</span>
      <p>该分类暂无内容</p>
    </div>

    <!-- ====== AI 问答弹出层 ====== -->
    <div v-if="showAiPanel" class="ai-overlay" @click.self="closeAi">
      <div class="ai-panel">
        <div class="ai-header">
          <span class="ai-title">🤖 懂车AI</span>
          <button class="ai-close" @click="closeAi">✕</button>
        </div>

        <div class="ai-body" ref="aiBodyRef">
          <!-- 空状态 -->
          <div v-if="!aiMessages.length" class="ai-empty">
            <span style="font-size:40px">🚗</span>
            <p>想了解什么车型？<br/>问我任何汽车问题！</p>
          </div>

          <!-- 消息列表 -->
          <div
            v-for="(msg, idx) in aiMessages"
            :key="idx"
            class="ai-msg"
            :class="msg.role === 'user' ? 'ai-user' : 'ai-assistant'"
          >
            <div class="ai-msg-avatar">{{ msg.role === 'user' ? '👤' : '🤖' }}</div>
            <div class="ai-msg-content">{{ msg.content }}</div>
          </div>

          <!-- 加载中 -->
          <div v-if="aiLoading" class="ai-msg ai-assistant">
            <div class="ai-msg-avatar">🤖</div>
            <div class="ai-msg-content ai-thinking">
              <span class="ai-dot">.</span><span class="ai-dot">.</span><span class="ai-dot">.</span>
            </div>
          </div>
        </div>

        <div class="ai-footer">
          <input
            v-model="aiInput"
            class="ai-input"
            placeholder="输入汽车问题..."
            @keyup.enter="sendAiMessage"
            :disabled="aiLoading"
          />
          <button class="ai-send" @click="sendAiMessage" :disabled="!aiInput.trim() || aiLoading">发送</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, nextTick } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const categories = ['推荐', '新车', '评测', '导购', '新能源', '二手车', '用车', '技术', '赛事']
const activeCat = ref('推荐')
const switchCategory = (cat) => { activeCat.value = cat }

// ====== AI 问答状态 ======
const searchText = ref('')
const showAiPanel = ref(false)
const aiInput = ref('')
const aiMessages = ref([])
const aiLoading = ref(false)
const aiBodyRef = ref(null)

const scrollAiToBottom = () => {
  nextTick(() => {
    if (aiBodyRef.value) aiBodyRef.value.scrollTop = aiBodyRef.value.scrollHeight
  })
}

const submitSearch = () => {
  if (!searchText.value.trim()) return
  // 把搜索文字填入AI输入框并打开面板
  aiInput.value = searchText.value
  showAiPanel.value = true
  // 自动发送
  setTimeout(() => sendAiMessage(), 300)
}

const closeAi = () => {
  showAiPanel.value = false
  searchText.value = ''
}

const sendAiMessage = async () => {
  const text = aiInput.value.trim()
  if (!text || aiLoading.value) return

  // 添加用户消息
  aiMessages.value.push({ role: 'user', content: text })
  aiInput.value = ''
  aiLoading.value = true
  scrollAiToBottom()

  try {
    const response = await fetch('/api/web/aichat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, conversationId: 'home-' + Date.now() })
    })
    const result = await response.json()
    if (result.code === 200) {
      aiMessages.value.push({ role: 'assistant', content: result.data })
    } else {
      aiMessages.value.push({ role: 'assistant', content: '抱歉，出错了，请稍后再试' })
    }
  } catch {
    aiMessages.value.push({ role: 'assistant', content: '网络连接失败，请检查网络' })
  } finally {
    aiLoading.value = false
    scrollAiToBottom()
  }
}

// ====== 图片容错 ======
const onImgError = (e) => { e.target.style.display = 'none' }

const carImgs = [
  'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400&h=300&fit=crop',
  'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400&h=300&fit=crop',
  'https://images.unsplash.com/photo-1502877338535-766e1452684a?w=400&h=300&fit=crop',
  'https://images.unsplash.com/photo-1533473359331-0135ef1b58d1?w=400&h=300&fit=crop',
  'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=400&h=300&fit=crop',
  'https://images.unsplash.com/photo-1554744511-d6c603f27c54?w=400&h=300&fit=crop',
  'https://images.unsplash.com/photo-1550355291-bbee04a92027?w=400&h=300&fit=crop',
]

const feedList = ref([
  { id: 1, cat: '推荐', title: '小米SU7 Ultra 赛道首测！1548匹马力', source: '汽车之家', views: '236万', img: carImgs[0], bg: '#1a1a2e', badge: '首发', badgeColor: '#E01E26', duration: '12:34' },
  { id: 2, cat: '推荐', title: '理想L9 2026款发布：充电12分钟续航500km', source: '电动邦', views: '189万', img: carImgs[3], bg: '#16213e', badge: '新车', badgeColor: '#FF6B35', duration: '15:20' },
  { id: 3, cat: '推荐', title: '问界M9 vs 理想L9 50万级SUV对比评测', source: '懂车评测', views: '312万', img: carImgs[5], bg: '#1a1a2e', badge: '对比', badgeColor: '#6C5CE7', duration: '18:20' },
  { id: 4, cat: '推荐', title: '特斯拉Cybertruck国内实车到店！', source: '电车实验室', views: '278万', img: carImgs[1], bg: '#2d1b00', badge: '热门', badgeColor: '#E01E26' },
  { id: 5, cat: '推荐', title: '比亚迪秦L DM-i 实测油耗仅2.1L', source: '用车报告', views: '198万', img: carImgs[2], bg: '#1a3636', badge: '实测', badgeColor: '#0984E3', duration: '08:50' },
  { id: 6, cat: '推荐', title: '10万级纯电轿车横评：秦PLUS vs 埃安S', source: '汽车导购', views: '156万', img: carImgs[4], bg: '#2d1b00', badge: '导购', badgeColor: '#00CEC9' },
  { id: 7, cat: '新车', title: '理想L9 2026款正式发布：42.98万起', source: '电动邦', views: '189万', img: carImgs[3], bg: '#16213e', badge: '发布', badgeColor: '#FF6B35', duration: '15:20' },
  { id: 8, cat: '新车', title: '比亚迪海狮07 EV亮相，或售18万起', source: '新车速递', views: '98万', img: carImgs[4], bg: '#1a3636', badge: '曝光', badgeColor: '#FF6B35' },
  { id: 9, cat: '新车', title: '小鹏X9 2026款：纯电MPV续航800km', source: '电动星球', views: '76万', img: carImgs[6], bg: '#1a1a2e', badge: '首发', badgeColor: '#E01E26' },
  { id: 10, cat: '新车', title: '奥迪A6 e-tron亮相：纯电版来了', source: '汽车前沿', views: '134万', img: carImgs[0], bg: '#2d1b00', badge: '首发', badgeColor: '#E01E26' },
  { id: 11, cat: '评测', title: '小米SU7 赛道对决保时捷Taycan', source: '汽车之家', views: '236万', img: carImgs[1], bg: '#1a1a2e', badge: '独家', badgeColor: '#E01E26', duration: '18:20' },
  { id: 12, cat: '评测', title: '智界S7深度体验：华为智驾多强？', source: '科技车评', views: '145万', img: carImgs[2], bg: '#2d1b00', badge: '深度', badgeColor: '#E17055' },
  { id: 13, cat: '评测', title: 'Model 3焕新版长测：3万公里后', source: '老司机说车', views: '134万', img: carImgs[5], bg: '#1a3636', badge: '长测', badgeColor: '#0984E3' },
  { id: 14, cat: '导购', title: '20万预算SUV怎么选？最值得买5款', source: '汽车导购', views: '156万', img: carImgs[3], bg: '#16213e', badge: '精选', badgeColor: '#00CEC9', duration: '12:10' },
  { id: 15, cat: '导购', title: '家用MPV怎么选？腾势D9 vs 传祺E9', source: '家庭买车', views: '87万', img: carImgs[6], bg: '#2d1b00', badge: '对比', badgeColor: '#6C5CE7' },
  { id: 16, cat: '新能源', title: '宁德时代麒麟电池实测续航1000km', source: '电动邦', views: '203万', img: carImgs[5], bg: '#1a3636', badge: '技术', badgeColor: '#00B894', duration: '14:30' },
  { id: 17, cat: '新能源', title: '充电桩建设提速：超充站数量翻倍', source: '新能源日报', views: '67万', img: carImgs[6], bg: '#1a1a2e', badge: '行业', badgeColor: '#00B894' },
  { id: 18, cat: '二手车', title: '2026年最保值车型排行榜出炉', source: '二手车之家', views: '187万', img: carImgs[4], bg: '#2d1b00', badge: '排行', badgeColor: '#E17055', duration: '10:15' },
  { id: 19, cat: '二手车', title: '二手车避坑指南：这5种别买', source: '老车评', views: '234万', img: carImgs[2], bg: '#16213e', badge: '干货', badgeColor: '#E17055' },
  { id: 20, cat: '用车', title: '夏季用车：空调、胎压、电池攻略', source: '用车宝典', views: '89万', img: carImgs[0], bg: '#1a3636', badge: '实用', badgeColor: '#0984E3', duration: '8:45' },
  { id: 21, cat: '用车', title: '电车充电技巧：怎样最省电？', source: '电动车主', views: '156万', img: carImgs[5], bg: '#1a1a2e', badge: '干货', badgeColor: '#00B894' },
  { id: 22, cat: '技术', title: '华为ADS 3.0 vs 特斯拉FSD v12', source: '智驾前沿', views: '234万', img: carImgs[1], bg: '#16213e', badge: '对比', badgeColor: '#6C5CE7', duration: '22:10' },
  { id: 23, cat: '技术', title: '比亚迪易四方技术深度解析', source: '汽车工程师', views: '78万', img: carImgs[0], bg: '#2d1b00', badge: '科普', badgeColor: '#0984E3' },
  { id: 24, cat: '赛事', title: 'F1中国站：周冠宇主场拿下积分！', source: '赛车天地', views: '312万', img: carImgs[1], bg: '#1a1a2e', badge: '热血', badgeColor: '#E01E26', duration: '20:30' },
  { id: 25, cat: '赛事', title: 'FE电动方程式：中国车队登顶', source: '电动赛事', views: '56万', img: carImgs[2], bg: '#1a3636', badge: '突破', badgeColor: '#00B894' },
])

const filteredList = computed(() => {
  if (activeCat.value === '推荐') return feedList.value.filter(item => item.cat === '推荐')
  return feedList.value.filter(item => item.cat === activeCat.value)
})

const goDetail = (item) => { router.push({ name: 'VideoView', params: { videoId: item.id } }) }
</script>

<style scoped>
.home-page { background: #f4f5f7; min-height: 100%; padding-bottom: 8px; }

/* ====== 搜索栏（现在是真的输入框） ====== */
.top-search { display: flex; align-items: center; padding: 10px 16px; background: #fff; gap: 12px; }
.search-input-wrap {
  flex: 1; display: flex; align-items: center; gap: 8px;
  background: #f5f6f8; border-radius: 20px; padding: 0 16px;
  border: 2px solid transparent; transition: border-color 0.2s;
}
.search-input-wrap:focus-within {
  border-color: #E01E26;
  background: #fff;
}
.search-input {
  flex: 1; border: none; background: transparent;
  font-size: 14px; padding: 10px 0; outline: none; font-family: inherit;
}
.top-actions { font-size: 20px; }

.category-scroll { background: #fff; border-bottom: 1px solid #f0f0f0; overflow-x: auto; }
.category-inner { display: flex; padding: 0 4px; }
.cat-pill { flex-shrink: 0; padding: 12px 16px; font-size: 14px; color: #606266; cursor: pointer; white-space: nowrap; border-bottom: 2px solid transparent; }
.cat-pill.active { color: #E01E26; font-weight: 600; border-bottom-color: #E01E26; }

.feed-header { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px 10px; }
.feed-header-title { font-size: 16px; font-weight: 700; color: #1a1a1a; display: flex; align-items: center; gap: 8px; }
.red-dot { width: 4px; height: 16px; background: #E01E26; border-radius: 2px; }
.feed-header-more { font-size: 12px; color: #909399; }

.feed-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding: 0 12px; }
.grid-card { background: #fff; border-radius: 10px; overflow: hidden; cursor: pointer; animation: fadeIn 0.25s ease; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
.grid-card:active { opacity: 0.85; }
.grid-img { position: relative; aspect-ratio: 4/3; overflow: hidden; display: flex; align-items: center; justify-content: center; }
.grid-img img { width: 100%; height: 100%; object-fit: cover; position: relative; z-index: 1; }
.car-emoji-bg { position: absolute; font-size: 60px; color: rgba(255,255,255,0.15); z-index: 0; pointer-events: none; }
.grid-badge { position: absolute; left: 8px; top: 8px; color: #fff; font-size: 10px; font-weight: 500; padding: 2px 7px; border-radius: 3px; z-index: 2; }
.grid-duration { position: absolute; right: 8px; bottom: 8px; background: rgba(0,0,0,0.7); color: #fff; font-size: 10px; padding: 1px 6px; border-radius: 3px; z-index: 2; }
.grid-body { padding: 10px 10px 12px; }
.grid-title { font-size: 13px; font-weight: 500; color: #1a1a1a; line-height: 1.4; margin: 0 0 6px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.grid-meta { display: flex; justify-content: space-between; font-size: 11px; color: #999; }
.list-end { grid-column: 1 / -1; text-align: center; padding: 20px 0 32px; font-size: 12px; color: #c0c4cc; }
.empty-cat { text-align: center; padding: 80px 0; color: #c0c4cc; display: flex; flex-direction: column; align-items: center; gap: 12px; }
.empty-cat p { font-size: 14px; margin: 0; }

/* ====== AI 弹窗 ====== */
.ai-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.4);
  display: flex; align-items: flex-end; justify-content: center;
  z-index: 1000; animation: fadeIn 0.2s;
}
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

.ai-panel {
  width: 100%; max-width: 480px; height: 80vh;
  background: #fff; border-radius: 16px 16px 0 0;
  display: flex; flex-direction: column;
  animation: slideUp 0.25s ease;
}
@keyframes slideUp { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

.ai-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 20px; border-bottom: 1px solid #eee; }
.ai-title { font-size: 16px; font-weight: 600; color: #1a1a1a; }
.ai-close { background: none; border: none; font-size: 18px; color: #999; cursor: pointer; padding: 4px; }

.ai-body { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 12px; }
.ai-empty { text-align: center; padding: 60px 0; color: #c0c4cc; display: flex; flex-direction: column; align-items: center; gap: 10px; }
.ai-empty p { font-size: 14px; margin: 0; line-height: 1.6; }

.ai-msg { display: flex; gap: 8px; max-width: 85%; animation: fadeIn 0.25s; }
.ai-user { align-self: flex-end; flex-direction: row-reverse; }
.ai-assistant { align-self: flex-start; }

.ai-msg-avatar { font-size: 20px; flex-shrink: 0; margin-top: 4px; }
.ai-msg-content { padding: 10px 14px; border-radius: 14px; font-size: 14px; line-height: 1.6; word-break: break-word; white-space: pre-wrap; }
.ai-user .ai-msg-content { background: #E01E26; color: #fff; border-bottom-right-radius: 4px; }
.ai-assistant .ai-msg-content { background: #f0f2f5; color: #1a1a1a; border-bottom-left-radius: 4px; }

.ai-thinking { display: flex; gap: 2px; padding: 14px 20px; }
.ai-dot { animation: dot 1.4s infinite; font-size: 20px; line-height: 1; color: #999; }
.ai-dot:nth-child(2) { animation-delay: 0.2s; }
.ai-dot:nth-child(3) { animation-delay: 0.4s; }
@keyframes dot { 0%,100% { opacity: 0.2; } 50% { opacity: 1; } }

.ai-footer { display: flex; gap: 8px; padding: 12px 16px 16px; border-top: 1px solid #eee; }
.ai-input {
  flex: 1; border: 1px solid #e4e7ed; border-radius: 20px;
  padding: 10px 16px; font-size: 14px; outline: none; font-family: inherit;
}
.ai-input:focus { border-color: #E01E26; }
.ai-send {
  background: #E01E26; color: #fff; border: none; border-radius: 20px;
  padding: 10px 20px; font-size: 14px; cursor: pointer; flex-shrink: 0;
}
.ai-send:disabled { opacity: 0.5; cursor: not-allowed; }
</style>
