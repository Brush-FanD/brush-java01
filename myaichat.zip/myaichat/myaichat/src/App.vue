<template>
  <div id="app">
    <div class="app-content">
      <router-view />
    </div>
    <div class="bottom-nav">
      <div
        v-for="tab in tabList"
        :key="tab.path"
        class="nav-item"
        :class="{ active: activeTab === tab.path }"
        @click="goPage(tab.path)"
      >
        <span class="nav-emoji">{{ tab.emoji }}</span>
        <span class="nav-label">{{ tab.label }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()

const tabList = [
  { path: '/home',   label: '首页',   emoji: '🏠' },
  { path: '/cars',   label: '选车',   emoji: '🚗' },
  { path: '/videos', label: '视频',   emoji: '🎬' },
]

const activeTab = computed(() => {
  if (route.path.startsWith('/video/')) return '/videos'
  return route.path
})

const goPage = (path) => {
  router.push(path)
}
</script>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body, #app { height: 100%; }
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f0f2f5;
  color: #1a1a1a;
}
#app {
  display: flex; flex-direction: column;
  max-width: 480px; margin: 0 auto;
  background: #f4f5f7;
}
.app-content { flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; }

.bottom-nav {
  display: flex; background: #fff;
  border-top: 1px solid #eee;
  flex-shrink: 0; height: 56px;
}
.nav-item {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  gap: 1px; cursor: pointer; padding: 4px 0 6px;
  user-select: none; -webkit-tap-highlight-color: transparent;
}
.nav-emoji { font-size: 22px; line-height: 1; }
.nav-label { font-size: 10px; color: #999; line-height: 1; }
.nav-item.active .nav-label { color: #E01E26; font-weight: 600; }
</style>
