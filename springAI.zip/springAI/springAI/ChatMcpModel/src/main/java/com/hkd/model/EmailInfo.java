package com.hkd.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.ai.tool.annotation.ToolParam;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
//@JsonIgnoreProperties(ignoreUnknown = true) // 👈 加上这个，完美解决 AI 乱加字段的问题
public class EmailInfo {
    //toolParam 标记该字段为Ai工具的入参项
    @ToolParam(description = "收件人邮箱", required = true)
    private String email;
    @ToolParam(description = "发送邮件的主题/标题", required = true)
    private String subject;
    @ToolParam(description = "发送邮件的内容", required = true)
    private String message;
}
