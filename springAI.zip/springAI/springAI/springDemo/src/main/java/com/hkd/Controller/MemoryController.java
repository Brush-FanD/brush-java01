package com.hkd.Controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/memory")
public class MemoryController {

    @Autowired
    @Qualifier("dormitoryChatClient")
    private ChatClient chatClient;


    //get请求
    @GetMapping("/chat")
    public String chat(@RequestParam String message,
                       @RequestParam String conversationID) {
        return chatClient.prompt().user(message)
                .advisors(
                        advidor -> advidor.param("conversationID",conversationID))
                .call().content();
    }
}
