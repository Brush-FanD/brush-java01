package com.hkd.Controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.swing.*;
import java.util.Map;
import java.util.Optional;
/**
 * 简单AI对话控制器
 * 演示Spring AI ChatClient最基本的用法
 *
 * 本Controller包含4个接口，从简单到复杂：
 * 1. /chat - 最简调用，直接返回AI回复文本
 * 2. /chat/info - 带Token统计，查看每次调用的Token消耗
 * 3. /chat/safe - 带错误处理，防止AI服务异常时接口崩溃
 * 4. /chat/strict - 覆盖模型参数，控制AI回复风格
 */
@RestController// 标记为REST控制器，返回值自动序列化为JSON
@RequestMapping("/simple")
public class SimpleChatController {
    // ChatClient：Spring AI 的核心API，用于与AI模型交互
    private final ChatClient chatClient;
    /**
     * 构造器注入 ChatClient.Builder
     * 为什么注入的是 Builder 而不是 ChatClient？
     * - ChatClient.Builder 由 Spring AI 自动配置（Auto-Configuration）创建
     * - 它已经绑定了 application.yaml 中配置的 DeepSeek 模型
     * - 我们调用 .build() 构建出一个最简单的 ChatClient 实例
     * - 如果需要带角色设定、带记忆的 ChatClient，需要在 build 之前配置
     */
    public SimpleChatController(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }
    /**
     * 【接口1】最简AI对话接口
     * GET /chat?message=你好
     * 调用链解读：
     * chatClient.prompt() → 创建一个PromptBuilder，开始构建请求
     * .user(message) → 设置用户消息内容
     * .call() → 同步调用AI模型，等待完整回复
     * .content() → 提取回复的文本内容（String类型）
     * 对比：如果用 .stream() 代替 .call()，就是流式调用（逐字输出）
     */
    @GetMapping("/chat")
    public String chat(@RequestParam String message) {
        return chatClient.prompt() // 开始构建提示词
                .user(message) // 设置用户消息
                .call() // 同步调用（阻塞等待AI回复完成）
                .content(); // 提取回复的纯文本内容
    }
    /**
     * 【接口2】带Token统计的AI对话接口
     * GET /chat/info?message=你好
     */
    @GetMapping("/chat/info")
    public Map<String, Object> chatInfo(@RequestParam String message) {
        ChatResponse chatResponse = chatClient.prompt()
                .user(message)
                .call()
                .chatResponse(); // 获取完整响应，包含内容和元数据
        String content = Optional.ofNullable(chatResponse.getResult())
                .map(result -> result.getOutput())
                .map(AssistantMessage::getText)
                .orElse("无响应内容");
//获取Token使用统计
        var usage = chatResponse.getMetadata().getUsage();

// 用Map组装返回结果（简单场景用Map，复杂场景建议用专用DTO类）
        return Map.of(
                "content", content, // AI回复的文本内容
                "promptTokens", usage.getPromptTokens(), // 输入Token数（你发给AI的）
                "completionTokens", usage.getCompletionTokens(), // 输出Token数（AI回复的）
                "totalTokens", usage.getTotalTokens() // 总Token数
        );
    }
    /**
     * 【接口3】带错误处理的AI对话接口
     * GET /chat/safe?message=你好
     */
    @GetMapping("/chat/safe")
    public Map<String, Object> chatSafe(@RequestParam String message) {
        try {
            String reply = chatClient.prompt()
                    .user(message)
                    .call()
                    .content();
// 成功时返回 success=true 和AI回复
            return Map.of("success", true, "reply", reply);
        } catch (Exception e) {
// 失败时返回 success=false 和友好提示
// 不把原始异常信息暴露给用户（可能包含敏感信息如API Key）
            return Map.of("success", false, "error", "AI服务暂时不可用：" +
                    e.getMessage());
        }
    }
    /**
     * 【接口4】覆盖模型参数的AI对话接口
     * GET /chat/strict?message=写一首诗
     *
     * 这个接口演示了如何在单次调用中覆盖 application.yaml 中的默认参数
     */
    @GetMapping("/chat/strict")
    public String chatStrict(@RequestParam String message) {
        return chatClient.prompt()
                .user(message)
                .options(ChatOptions.builder()
                        .temperature(0.1) // 覆盖温度：0.1（非常确定）
                        .maxTokens(500) // 限制最大输出Token数
                        .build())
                .call()
                .content();
    }
}