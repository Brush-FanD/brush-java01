package com.hkd.Controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ModeController {

    //第一步 创建chatClient
//    @Autowired
//    private ChatClient chatClient;
    private final ChatClient chatClient;


    public ModeController(ChatClient.Builder builder) {
        this.chatClient = builder.build();
    }

    @GetMapping("/system")
    public String chatSystem(@RequestParam String message){
        return chatClient.prompt()
                .system("你是龙出，回答问题简洁，不超过50字")
                .user(message)
                .call()
                .content();
    }


    @GetMapping("/template")
    public String withTemplate(
            @RequestParam String building,
            @RequestParam String student){
        return chatClient.prompt()
                .system("你是龙出，回答问题简洁，不超过50字")
                .user(
                        u -> u.text("帮我查{building}楼的{student}的考勤记录，并给出分析")
                                .param("building", building)
                                .param("student", student)
                )
                .call().content();


    }


}