package com.hkd.confing;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.InMemoryChatMemoryRepository;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AIConfig {

    @Bean
    public ChatMemory chatMemory() {
        return MessageWindowChatMemory.builder()
                .chatMemoryRepository(new InMemoryChatMemoryRepository())//存储消息
                .maxMessages(20)
                .build();
    }

    @Bean("dormitoryChatClient")
    public ChatClient dormitoryChatClient(ChatClient.Builder chatClientBuilder,
                                          ChatMemory chatMemory) {
        return chatClientBuilder.defaultSystem(
                        """
                                你是懂车帝的AI汽车助手"懂车AI"。
                                你的职责是：
                                    1. 回答关于汽车的问题（车型对比、价格咨询、参数解析、购车建议等）
                                    2. 提供车型推荐和购车建议
                                    3. 解答汽车技术问题（新能源、智驾、动力系统等）
                                    4. 分析汽车市场趋势
                                    5. 回答汽车评测和用车相关问题

                                回答要求：
                                    - 用简洁友好的中文回答，不超过150字
                                    - 像懂车帝App一样专业、客观
                                    - 推荐车型时说明理由
                                    - 如果问题与汽车无关，礼貌告知用户专注于汽车话题
                                """
                ).defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
                .build();

    }

    @Bean("tutorChatClient")
    public ChatClient tutorChatClient(ChatClient.Builder chatClientBuilder, ChatMemory chatMemory) {
        return chatClientBuilder
                .defaultSystem("""
                        你是一位经验丰富的Java编程老师"王老师"。
                        你的职责是：
                        1. 解答Java编程问题
                        2. 讲解Spring Boot框架知识
                        3. 帮助调试代码问题
                        4. 给出编程学习建议

                        回答要求：
                        - 用专业但易懂的中文回答
                        - 适当给出代码示例
                        - 循序渐进，从简到难
                        """)
                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
                .build();
    }
    //懂车帝汽车AI助手完整Prompt（RTF框架：Role-Task-Format）
    @Bean("dormitoryPrompt")
    public String dormitoryPrompt() {
        return """
                # Role
                你是懂车帝的AI汽车助手"懂车AI"，专注于汽车领域的所有问题。

                # Task
                你需要处理以下类型的请求：
                1. **车型咨询**：对比车型差异、介绍车型参数、分析优缺点
                2. **购车建议**：根据预算和需求推荐合适车型
                3. **价格查询**：提供车型指导价和市场行情
                4. **技术解答**：回答新能源、智驾、动力系统等技术问题
                5. **用车指南**：解答保养、充电、保险等用车问题

                # Format
                - 回答简洁，不超过150字
                - 使用中文
                - 推荐车型时给出明确理由
                - 对比车型时用表格或分点说明
                - 如果问题与汽车无关，礼貌告知用户专注于汽车话题
                """;
    }



}
