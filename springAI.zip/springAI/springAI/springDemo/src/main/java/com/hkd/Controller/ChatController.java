package com.hkd.Controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.metadata.Usage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.ai.chat.messages.AssistantMessage;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/chat")
public class ChatController {
    /*
     * 为什么要引入ChatClient 类
     * 他是一个spring AI自动配置的过程，通过Builder模式创建ChatClient对象
     *  builder 构建一个最简单的ChatClient实例
     */
    private final ChatClient chatClient;

    public ChatController(ChatClient.Builder builder) {
        this.chatClient = builder.build();
    }
    // localhost:8081/chat?prompt=你是谁
    @GetMapping
    public String chat(@RequestParam String prompt){
        return chatClient.prompt() //开始提示词构建
                .user(prompt) //用户输入提示词
                .call()    // 同步通信
                .content(); //获取返回结果
    }
    // 获取token用量
    @GetMapping("/info")
    public Map<String, Object> chatInfo(@RequestParam String message){
        ChatResponse chatResponse = chatClient.prompt()
                .user(message)
                .call()
                .chatResponse(); // 获取响应的完整元数据和内容

        String content = Optional.ofNullable(chatResponse.getResult())
                .map(result -> result.getOutput())
                .map(AssistantMessage::getText)
                .orElse("没有响应的内容");
        // 获取token用量
        Usage usage = chatResponse.getMetadata().getUsage();
        return Map.of(
                "content", content, //Ai回复的内容
                "promptTokens", usage.getPromptTokens(), //输入的tokens的数量
                "completionTokens", usage.getCompletionTokens(), //输出回复内容的token
                "totalTokens", usage.getTotalTokens() //总token数
        );


    }

    //覆盖模型参数的AI对话接口
    @GetMapping("/model")
    public String chatWithModel(@RequestParam String msg){
        return chatClient.prompt()
                .user(msg)
                .options(ChatOptions.builder()
                        .temperature(0.9)
                        .maxTokens(500)
                        .build())
                .call()
                .content();
    }


    //system的作用

}
