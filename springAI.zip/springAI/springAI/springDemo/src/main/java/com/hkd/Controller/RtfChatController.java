package com.hkd.Controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

public class RtfChatController {

    private final ChatClient chatClient;

    private final String dormitoryPrompt;

    public RtfChatController(ChatClient.Builder chatClientBuilder,
                             @Qualifier("dormitoryPrompt")String dormitoryPrompt) {
        this.chatClient = chatClientBuilder.build();
        this.dormitoryPrompt = dormitoryPrompt;

    }

    @GetMapping("/chat")
    public String chat(@RequestParam String message) {
        return chatClient.prompt()
                .system(dormitoryPrompt)
                .user(message)
                .call()
                .content();
    }
}
