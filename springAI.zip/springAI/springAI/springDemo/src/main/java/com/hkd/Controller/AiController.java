package com.hkd.Controller;

import com.hkd.dto.Result;
import com.hkd.service.AiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/ai")
public class AiController {
    @Autowired
    private AiService aiService;

    @GetMapping("/chat")
    public Result<String> chat(@RequestParam String message,
                               @RequestParam String conversationID){
        String chats = aiService.chat(message, conversationID);
        return Result.success(chats);
    }
    //流式输出

    @GetMapping(value = "/chatStream",produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> chatStream(@RequestParam String message,
                                   @RequestParam String conversationID){
        // 返回的是flux springboot把他自动转换为SSE流
        return aiService.chatStream(message, conversationID);

    }

}
