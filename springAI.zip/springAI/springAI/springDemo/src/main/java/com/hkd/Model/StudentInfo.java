package com.hkd.Model;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class StudentInfo {
    // Ai会根据用户描述，生成一个学生姓名
    private String name;
    // Ai会根据用户描述，生成一个学生宿舍楼
    private String building;
    // Ai会根据用户描述，生成一个学生宿舍号
    private String room;
    //手机号
    private String phone;

    //宿舍考勤
    private String attendance;

}
