package com.hkd.service.impl;

import com.hkd.service.AiService;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.net.SocketTimeoutException;

@Service
public class AiServiceImpl implements AiService {

    @Autowired
    @Qualifier("dormitoryChatClient")
    private ChatClient chatClient;

    @Override
    public String chat(String message,String conversationID){
        try {
            return chatClient.prompt().user(message)
                    .advisors(
                            advisor -> advisor.param("conversationID",conversationID))
                    .call().content();
        }catch (Exception e){
            System.out.println("AI同步异常：" + e.getMessage());
            return "AI同步异常" + e.getMessage();
        }
    }
    @Override
    public Flux<String> chatStream(String message,String conversationID){
        try {
            return chatClient.prompt()
                    .user(message)
                    .advisors(
                            advisor -> advisor.param("conversationID",conversationID))
                    .stream().content();
        }catch (Exception e){
            return Flux.just("AI同步异常：" + e.getMessage());
        }
    }
}
