package com.hkd.confing;

import lombok.Data;

@Data
public class ChatRequest {

    private String message;

    private String conversationId="default";
}
