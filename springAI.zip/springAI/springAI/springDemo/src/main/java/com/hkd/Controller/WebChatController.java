package com.hkd.Controller;

import com.hkd.confing.ChatRequest;
import com.hkd.dto.Result;
import com.hkd.service.AiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/web"

)
public class WebChatController {

    @Autowired
    private AiService aiService;


    //同步
    @PostMapping("/aichat")
    public Result<String> aiChat(@RequestBody ChatRequest chatRequest){
        String chats = aiService.chat(chatRequest.getMessage(),
                chatRequest.getConversationId());
        return Result.success(chats);
    }


    @GetMapping("/chatstream")
    public Flux<String> aiChatStream(@RequestParam String message,
                                     @RequestParam String conversationId){
        return aiService.chatStream(message, conversationId);
    }

}
