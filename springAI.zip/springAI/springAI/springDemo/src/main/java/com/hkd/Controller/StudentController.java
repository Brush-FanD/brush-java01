package com.hkd.Controller;

import com.hkd.Model.StudentInfo;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
    @Autowired
    @Qualifier("dormitoryChatClient")
    private ChatClient chatClient;


    @GetMapping("/stu")
    public StudentInfo chatStudent(String msg){
        return chatClient.prompt()
                .system("从用户描述中提取学生信息，按JSON格式返回，字段：name/building/room/phone/attendance")
                .user(msg)
                .call()
                .entity(StudentInfo.class);
    }

}
