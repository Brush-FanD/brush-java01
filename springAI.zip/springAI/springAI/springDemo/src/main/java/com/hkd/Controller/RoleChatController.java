package com.hkd.Controller;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/roleChat")
public class RoleChatController {
    @Autowired
    @Qualifier("dormitoryChatClient")
    private ChatClient dormitoryClient;
    @Autowired
    @Qualifier("tutorChatClient")
    private ChatClient tutorClient;

    @GetMapping("/dormitory")
    public String dormitoryChat(@RequestParam String message) {
        return dormitoryClient.prompt()
                .user(message)
                .call()
                .content();
    }

    @GetMapping("/tutor")
    public String tutorChat(@RequestParam String message) {
        return tutorClient.prompt()
                .user(message)
                .call()
                .content();
    }

    @GetMapping("/compare")
    public Map<String, String> compare(String message) {
        //宿舍管理助手
        String dormitory = dormitoryClient.prompt()
                .user(message).call().content();
        //编程老师
        String tutor = tutorClient.prompt()
                .user(message).call().content();

        return  Map.of("dormitory",dormitory
        ,"tutor",tutor);
    }
}
